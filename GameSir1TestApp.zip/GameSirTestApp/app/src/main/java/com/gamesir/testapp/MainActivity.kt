package com.gamesir.testapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.viewmodel.compose.viewModel
import com.gamesir.testapp.ui.MainScreen
import com.gamesir.testapp.ui.MainViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            GameSirTestTheme {
                val viewModel: MainViewModel = viewModel()
                MainScreen(viewModel)
            }
        }
    }
}

@Composable
fun GameSirTestTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val colors = if (dark) {
        darkColorScheme(
            primary = Color(0xFF90CAF9),
            primaryContainer = Color(0xFF1565C0),
            secondary = Color(0xFF80CBC4)
        )
    } else {
        lightColorScheme(
            primary = Color(0xFF1565C0),
            primaryContainer = Color(0xFFBBDEFB),
            secondary = Color(0xFF00796B)
        )
    }
    MaterialTheme(colorScheme = colors, content = content)
}
