package com.gamesir.testapp.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.gamesir.testapp.ble.BleManager
import com.gamesir.testapp.model.*
import com.gamesir.testapp.protocol.gcm.GcmCodec
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    val bleManager = BleManager(application)

    /** Modo somente leitura por padrão (guia §8 e §9) */
    private val _readOnlyMode = MutableStateFlow(true)
    val readOnlyMode: StateFlow<Boolean> = _readOnlyMode.asStateFlow()

    private val _experimentalUnlocked = MutableStateFlow(false)
    val experimentalUnlocked: StateFlow<Boolean> = _experimentalUnlocked.asStateFlow()

    private val _selectedPreset = MutableStateFlow<CommandPreset?>(null)
    val selectedPreset: StateFlow<CommandPreset?> = _selectedPreset.asStateFlow()

    private val _rawHexInput = MutableStateFlow("")
    val rawHexInput: StateFlow<String> = _rawHexInput.asStateFlow()

    private val _hexValidation = MutableStateFlow("")
    val hexValidation: StateFlow<String> = _hexValidation.asStateFlow()

    private val _showResetConfirm = MutableStateFlow(false)
    val showResetConfirm: StateFlow<Boolean> = _showResetConfirm.asStateFlow()

    val presets = GcmCodec.knownPresets

    fun toggleReadOnly() {
        // Só permite desligar se experimental estiver desbloqueado
        if (_readOnlyMode.value && !_experimentalUnlocked.value) return
        _readOnlyMode.value = !_readOnlyMode.value
    }

    fun unlockExperimental(confirm: Boolean) {
        _experimentalUnlocked.value = confirm
        if (!confirm) _readOnlyMode.value = true
    }

    fun selectPreset(preset: CommandPreset?) {
        _selectedPreset.value = preset
        if (preset != null) {
            _rawHexInput.value = preset.packet.toHexString()
            validateHex()
        }
    }

    fun updateRawHex(hex: String) {
        _rawHexInput.value = hex
        validateHex()
    }

    private fun validateHex() {
        val (ok, msg) = GcmCodec.validateRawHex(_rawHexInput.value)
        _hexValidation.value = if (ok) "✓ $msg" else "✗ $msg"
    }

    fun startScan() = bleManager.startScan()
    fun stopScan() = bleManager.stopScan()
    fun connect(address: String) = bleManager.connect(address)
    fun disconnect() = bleManager.disconnect()

    /**
     * Envia o pacote atual.
     * Respeita modo somente leitura e bloqueio de Reset.
     */
    fun sendCurrentPacket() {
        val hex = _rawHexInput.value
        val bytes = hex.hexToBytes() ?: return
        if (!GcmCodec.isChecksumValid(bytes)) return

        val packet = GcmCodec.parse(bytes)
        if (packet != null) {
            when (packet.op) {
                GcmOp.RESET -> {
                    if (_readOnlyMode.value) return
                    // Exige confirmação dupla
                    _showResetConfirm.value = true
                    return
                }
                GcmOp.SET -> {
                    if (_readOnlyMode.value) return
                }
                GcmOp.QUERY -> { /* sempre permitido */ }
            }
        } else if (_readOnlyMode.value) {
            // Pacote desconhecido em modo leitura: bloquear
            return
        }

        bleManager.writeBytes(bytes)
    }

    fun confirmResetAndSend() {
        _showResetConfirm.value = false
        val bytes = _rawHexInput.value.hexToBytes() ?: return
        bleManager.writeBytes(bytes)
    }

    fun cancelReset() {
        _showResetConfirm.value = false
    }

    fun enableNotifications() {
        bleManager.enableNotifications()
    }

    fun clearLogs() = bleManager.clearLogs()

    fun exportLogs(): String = bleManager.exportLogsAsText()
}
