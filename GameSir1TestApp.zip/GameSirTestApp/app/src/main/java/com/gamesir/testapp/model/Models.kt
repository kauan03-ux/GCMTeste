package com.gamesir.testapp.model

import java.util.UUID

/**
 * Níveis de confiança conforme o guia.
 */
enum class Confidence {
    HIGH,           // Confirmado por testes unitários / captura
    STATIC_HIGH,    // Achado estático forte no APK/SDK
    PARTIAL,        // Parcialmente conhecido
    PENDING,        // Precisa de confirmação física
    EXPERIMENTAL    // Não validado
}

/**
 * Operações GCM observadas no SDK.
 */
enum class GcmOp(val code: Int) {
    QUERY(0x00),
    SET(0x01),
    RESET(0x02);

    companion object {
        fun fromCode(code: Int): GcmOp? = entries.find { it.code == code }
    }
}

/**
 * Pacote GCM básico (6 bytes) conforme exemplos do guia.
 * Formato: 1F | OP | ID | VALUE | 00 | CHECKSUM
 */
data class GcmPacket(
    val op: GcmOp,
    val id: Int,
    val value: Int,
    val reserved: Int = 0x00
) {
    fun toByteArray(): ByteArray {
        val body = byteArrayOf(
            0x1F.toByte(),
            op.code.toByte(),
            id.toByte(),
            value.toByte(),
            reserved.toByte()
        )
        val checksum = body.sumOf { it.toUByte().toInt() } and 0xFF
        return body + byteArrayOf(checksum.toByte())
    }

    fun toHexString(): String = toByteArray().toHex()

    companion object {
        fun fromBytes(bytes: ByteArray): GcmPacket? {
            if (bytes.size < 6) return null
            if (bytes[0] != 0x1F.toByte()) return null
            if (!isChecksumValid(bytes)) return null
            val op = GcmOp.fromCode(bytes[1].toUByte().toInt()) ?: return null
            return GcmPacket(
                op = op,
                id = bytes[2].toUByte().toInt(),
                value = bytes[3].toUByte().toInt(),
                reserved = bytes[4].toUByte().toInt()
            )
        }

        fun isChecksumValid(packet: ByteArray): Boolean {
            if (packet.size < 2) return false
            val expected = packet.dropLast(1).sumOf { it.toUByte().toInt() } and 0xFF
            return expected == packet.last().toUByte().toInt()
        }
    }
}

fun ByteArray.toHex(): String =
    joinToString(" ") { "%02X".format(it.toUByte().toInt()) }

fun String.hexToBytes(): ByteArray? {
    val cleaned = this.replace(" ", "").replace(":", "").replace("-", "")
    if (cleaned.length % 2 != 0) return null
    return try {
        cleaned.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
    } catch (e: NumberFormatException) {
        null
    }
}

/**
 * Dispositivo BLE encontrado no scan.
 */
data class BleDeviceInfo(
    val name: String?,
    val address: String,
    val rssi: Int,
    val lastSeen: Long = System.currentTimeMillis()
)

/**
 * Characteristic GATT com propriedades.
 */
data class GattCharacteristicInfo(
    val uuid: UUID,
    val properties: Int,
    val permissions: Int,
    val descriptors: List<UUID> = emptyList()
) {
    val canRead: Boolean get() = properties and android.bluetooth.BluetoothGattCharacteristic.PROPERTY_READ != 0
    val canWrite: Boolean get() = properties and android.bluetooth.BluetoothGattCharacteristic.PROPERTY_WRITE != 0
    val canWriteNoResponse: Boolean get() = properties and android.bluetooth.BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0
    val canNotify: Boolean get() = properties and android.bluetooth.BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0
    val canIndicate: Boolean get() = properties and android.bluetooth.BluetoothGattCharacteristic.PROPERTY_INDICATE != 0

    fun propertiesString(): String {
        val parts = mutableListOf<String>()
        if (canRead) parts += "READ"
        if (canWrite) parts += "WRITE"
        if (canWriteNoResponse) parts += "WRITE_NO_RESP"
        if (canNotify) parts += "NOTIFY"
        if (canIndicate) parts += "INDICATE"
        return parts.joinToString(" | ").ifEmpty { "NONE" }
    }
}

data class GattServiceInfo(
    val uuid: UUID,
    val characteristics: List<GattCharacteristicInfo>
)

/**
 * Entrada de log TX/RX.
 */
enum class LogDirection { TX, RX, INFO, ERROR, TIMEOUT }

data class LogEntry(
    val timestamp: Long,
    val direction: LogDirection,
    val message: String,
    val bytesHex: String? = null,
    val characteristicUuid: String? = null,
    val gattStatus: Int? = null
) {
    fun formattedTimestamp(): String {
        val sdf = java.text.SimpleDateFormat("HH:mm:ss.SSS", java.util.Locale.US)
        return sdf.format(java.util.Date(timestamp))
    }
}

/**
 * Estado da conexão BLE.
 */
sealed class BleConnectionState {
    data object Idle : BleConnectionState()
    data object Scanning : BleConnectionState()
    data class Connecting(val address: String) : BleConnectionState()
    data class Connected(
        val name: String?,
        val address: String,
        val services: List<GattServiceInfo> = emptyList()
    ) : BleConnectionState()
    data class Error(val message: String) : BleConnectionState()
}

/**
 * Preset de comando conhecido (somente leitura por padrão).
 */
data class CommandPreset(
    val name: String,
    val packet: GcmPacket,
    val confidence: Confidence,
    val description: String
)

/**
 * UUIDs conhecidos do SDK (pistas, não autorização automática).
 */
object KnownUuids {
    val SERVICE_GAMESIR = UUID.fromString("00008650-0000-1000-8000-00805f9b34fb")
    val CHAR_HANDLE_DATA = UUID.fromString("00008655-0000-1000-8000-00805f9b34fb")
    val CHAR_OTHER = UUID.fromString("00008651-0000-1000-8000-00805f9b34fb")
    val CCCD = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
}
