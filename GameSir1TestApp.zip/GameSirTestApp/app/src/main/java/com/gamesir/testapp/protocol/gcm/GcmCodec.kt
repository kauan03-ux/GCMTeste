package com.gamesir.testapp.protocol.gcm

import com.gamesir.testapp.model.CommandPreset
import com.gamesir.testapp.model.Confidence
import com.gamesir.testapp.model.GcmOp
import com.gamesir.testapp.model.GcmPacket

/**
 * Codec didático do protocolo GCM observado no APK.
 *
 * Formato básico (6 bytes):
 *   1F | OP | ID | VALUE | 00 | CHECKSUM
 *
 * OP: 00=Query, 01=Set, 02=Reset
 * CHECKSUM = soma dos bytes anteriores módulo 256
 *
 * IMPORTANTE: este encoder cobre apenas o formato de 6 bytes dos exemplos.
 * Não generalizar para formatos variáveis sem confirmar no Super Nova físico.
 */
object GcmCodec {

    /**
     * Codifica um pacote GCM básico.
     */
    fun encodeBasic(op: GcmOp, id: Int, value: Int, reserved: Int = 0): ByteArray {
        require(id in 0..255) { "ID must be 0-255" }
        require(value in 0..255) { "VALUE must be 0-255" }
        require(reserved in 0..255) { "RESERVED must be 0-255" }
        return GcmPacket(op, id, value, reserved).toByteArray()
    }

    /**
     * Valida checksum de um pacote.
     */
    fun isChecksumValid(packet: ByteArray): Boolean = GcmPacket.isChecksumValid(packet)

    /**
     * Tenta parsear um pacote recebido.
     */
    fun parse(packet: ByteArray): GcmPacket? = GcmPacket.fromBytes(packet)

    /**
     * Calcula checksum de um body (sem o byte final).
     */
    fun calculateChecksum(body: ByteArray): Int =
        body.sumOf { it.toUByte().toInt() } and 0xFF

    /**
     * Presets conhecidos dos exemplos do guia (confiança estática).
     * Set/Reset ficam bloqueados no modo somente leitura.
     */
    val knownPresets: List<CommandPreset> = listOf(
        CommandPreset(
            name = "Query ID 0x01",
            packet = GcmPacket(GcmOp.QUERY, 0x01, 0x00),
            confidence = Confidence.STATIC_HIGH,
            description = "Query para ID 01 — bytes: 1F 00 01 00 00 20"
        ),
        CommandPreset(
            name = "Query ID 0x02",
            packet = GcmPacket(GcmOp.QUERY, 0x02, 0x00),
            confidence = Confidence.EXPERIMENTAL,
            description = "Query para ID 02 (experimental)"
        ),
        CommandPreset(
            name = "Set ID 0x01 = 0xC1",
            packet = GcmPacket(GcmOp.SET, 0x01, 0xC1),
            confidence = Confidence.STATIC_HIGH,
            description = "Set exemplo do guia — valor C1 (significado semântico NÃO confirmado)"
        ),
        CommandPreset(
            name = "Set ID 0x01 = 0xB7",
            packet = GcmPacket(GcmOp.SET, 0x01, 0xB7),
            confidence = Confidence.STATIC_HIGH,
            description = "Set exemplo do guia — valor B7 (significado semântico NÃO confirmado)"
        ),
        CommandPreset(
            name = "Reset ID 0x01",
            packet = GcmPacket(GcmOp.RESET, 0x01, 0x00),
            confidence = Confidence.STATIC_HIGH,
            description = "Reset para ID 01 — DESTRUTIVO, exige confirmação dupla"
        )
    )

    /**
     * Verifica se um pacote hexadecimal bruto tem checksum válido.
     */
    fun validateRawHex(hex: String): Pair<Boolean, String> {
        val bytes = com.gamesir.testapp.model.hexToBytes(hex)
            ?: return false to "Hex inválido"
        if (bytes.isEmpty()) return false to "Pacote vazio"
        if (!isChecksumValid(bytes)) {
            val expected = calculateChecksum(bytes.dropLast(1).toByteArray())
            return false to "Checksum inválido (esperado 0x%02X, recebido 0x%02X)".format(
                expected, bytes.last().toUByte().toInt()
            )
        }
        return true to "Checksum OK (${bytes.size} bytes)"
    }
}
