package com.gamesir.testapp.ble

import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.os.Build
import android.util.Log
import com.gamesir.testapp.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * Gerenciador BLE — scan, conexão, descoberta GATT e escrita/notificação.
 *
 * Regras do guia:
 * - Não transmitir automaticamente ao conectar
 * - Não escrever em todas as characteristics
 * - Registrar TX, status GATT, RX e timeout separadamente
 * - Desconectar e liberar GATT corretamente
 */
@SuppressLint("MissingPermission")
class BleManager(private val context: Context) {

    companion object {
        private const val TAG = "BleManager"
        private const val DEFAULT_TIMEOUT_MS = 3000L
    }

    private val bluetoothManager =
        context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
    private val adapter: BluetoothAdapter? = bluetoothManager.adapter

    private var gatt: BluetoothGatt? = null
    private var writeCharacteristic: BluetoothGattCharacteristic? = null
    private var notifyCharacteristic: BluetoothGattCharacteristic? = null

    private val _connectionState = MutableStateFlow<BleConnectionState>(BleConnectionState.Idle)
    val connectionState: StateFlow<BleConnectionState> = _connectionState.asStateFlow()

    private val _scannedDevices = MutableStateFlow<List<BleDeviceInfo>>(emptyList())
    val scannedDevices: StateFlow<List<BleDeviceInfo>> = _scannedDevices.asStateFlow()

    private val _logs = MutableStateFlow<List<LogEntry>>(emptyList())
    val logs: StateFlow<List<LogEntry>> = _logs.asStateFlow()

    private val deviceMap = ConcurrentHashMap<String, BleDeviceInfo>()

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val device = result.device ?: return
            val name = device.name ?: result.scanRecord?.deviceName
            val info = BleDeviceInfo(
                name = name,
                address = device.address,
                rssi = result.rssi
            )
            deviceMap[device.address] = info
            _scannedDevices.value = deviceMap.values.sortedByDescending { it.rssi }
        }

        override fun onScanFailed(errorCode: Int) {
            addLog(LogDirection.ERROR, "Scan falhou: código $errorCode")
            _connectionState.value = BleConnectionState.Error("Scan falhou ($errorCode)")
        }
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            when (newState) {
                BluetoothProfile.STATE_CONNECTED -> {
                    addLog(LogDirection.INFO, "BLE_CONNECTED name=\"${g.device.name}\" address=${g.device.address}")
                    _connectionState.value = BleConnectionState.Connected(
                        name = g.device.name,
                        address = g.device.address
                    )
                    g.discoverServices()
                }
                BluetoothProfile.STATE_DISCONNECTED -> {
                    addLog(LogDirection.INFO, "DISCONNECT status=$status")
                    closeGatt()
                    _connectionState.value = BleConnectionState.Idle
                }
            }
            if (status != BluetoothGatt.GATT_SUCCESS && newState != BluetoothProfile.STATE_DISCONNECTED) {
                addLog(LogDirection.ERROR, "Connection state change error: status=$status")
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                addLog(LogDirection.ERROR, "Service discovery failed: $status")
                return
            }
            val services = g.services.map { service ->
                addLog(LogDirection.INFO, "GATT_SERVICE uuid=${service.uuid}")
                GattServiceInfo(
                    uuid = service.uuid,
                    characteristics = service.characteristics.map { char ->
                        val descriptors = char.descriptors.map { it.uuid }
                        addLog(
                            LogDirection.INFO,
                            "  CHAR uuid=${char.uuid} props=${char.properties} descriptors=$descriptors"
                        )
                        GattCharacteristicInfo(
                            uuid = char.uuid,
                            properties = char.properties,
                            permissions = char.permissions,
                            descriptors = descriptors
                        )
                    }
                )
            }
            // Tenta selecionar a characteristic conhecida do SDK
            selectKnownCharacteristic(g)
            val current = _connectionState.value
            if (current is BleConnectionState.Connected) {
                _connectionState.value = current.copy(services = services)
            }
        }

        override fun onCharacteristicWrite(
            g: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            status: Int
        ) {
            val hex = characteristic.value?.toHex() ?: "?"
            addLog(
                direction = if (status == BluetoothGatt.GATT_SUCCESS) LogDirection.TX else LogDirection.ERROR,
                message = "WRITE status=$status",
                bytesHex = hex,
                characteristicUuid = characteristic.uuid.toString(),
                gattStatus = status
            )
        }

        override fun onCharacteristicChanged(
            g: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic
        ) {
            @Suppress("DEPRECATION")
            val value = characteristic.value
            addLog(
                direction = LogDirection.RX,
                message = "NOTIFY",
                bytesHex = value?.toHex(),
                characteristicUuid = characteristic.uuid.toString()
            )
        }

        @Deprecated("Deprecated in API")
        override fun onCharacteristicChanged(
            g: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            value: ByteArray
        ) {
            addLog(
                direction = LogDirection.RX,
                message = "NOTIFY",
                bytesHex = value.toHex(),
                characteristicUuid = characteristic.uuid.toString()
            )
        }

        override fun onCharacteristicRead(
            g: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            status: Int
        ) {
            @Suppress("DEPRECATION")
            val value = characteristic.value
            addLog(
                direction = if (status == BluetoothGatt.GATT_SUCCESS) LogDirection.RX else LogDirection.ERROR,
                message = "READ status=$status",
                bytesHex = value?.toHex(),
                characteristicUuid = characteristic.uuid.toString(),
                gattStatus = status
            )
        }

        override fun onDescriptorWrite(
            g: BluetoothGatt,
            descriptor: BluetoothGattDescriptor,
            status: Int
        ) {
            addLog(
                LogDirection.INFO,
                "DESCRIPTOR_WRITE uuid=${descriptor.uuid} status=$status"
            )
        }
    }

    fun isBluetoothEnabled(): Boolean = adapter?.isEnabled == true

    fun startScan() {
        if (adapter == null || !adapter.isEnabled) {
            _connectionState.value = BleConnectionState.Error("Bluetooth desligado")
            return
        }
        deviceMap.clear()
        _scannedDevices.value = emptyList()
        _connectionState.value = BleConnectionState.Scanning
        addLog(LogDirection.INFO, "SCAN_START")

        val settings = ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
            .build()

        adapter.bluetoothLeScanner?.startScan(null, settings, scanCallback)
    }

    fun stopScan() {
        adapter?.bluetoothLeScanner?.stopScan(scanCallback)
        if (_connectionState.value is BleConnectionState.Scanning) {
            _connectionState.value = BleConnectionState.Idle
        }
        addLog(LogDirection.INFO, "SCAN_STOP")
    }

    fun connect(address: String) {
        stopScan()
        val device = adapter?.getRemoteDevice(address) ?: run {
            addLog(LogDirection.ERROR, "Dispositivo não encontrado: $address")
            return
        }
        _connectionState.value = BleConnectionState.Connecting(address)
        addLog(LogDirection.INFO, "CONNECTING address=$address")

        gatt = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            device.connectGatt(context, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
        } else {
            @Suppress("DEPRECATION")
            device.connectGatt(context, false, gattCallback)
        }
    }

    fun disconnect() {
        addLog(LogDirection.INFO, "DISCONNECT reason=user")
        gatt?.disconnect()
        // onConnectionStateChange fará o close
    }

    fun closeGatt() {
        gatt?.close()
        gatt = null
        writeCharacteristic = null
        notifyCharacteristic = null
    }

    /**
     * Envia bytes brutos para a characteristic de escrita selecionada.
     * Nunca chama automaticamente.
     */
    fun writeBytes(bytes: ByteArray, characteristicUuid: UUID? = null): Boolean {
        val g = gatt ?: run {
            addLog(LogDirection.ERROR, "GATT não conectado")
            return false
        }
        val char = when {
            characteristicUuid != null -> findCharacteristic(g, characteristicUuid)
            writeCharacteristic != null -> writeCharacteristic
            else -> {
                addLog(LogDirection.ERROR, "Nenhuma characteristic de escrita selecionada")
                return false
            }
        } ?: run {
            addLog(LogDirection.ERROR, "Characteristic não encontrada")
            return false
        }

        addLog(
            LogDirection.TX,
            "TX transport=BLE",
            bytesHex = bytes.toHex(),
            characteristicUuid = char.uuid.toString()
        )

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val result = g.writeCharacteristic(
                char,
                bytes,
                BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
            )
            result == BluetoothStatusCodes.SUCCESS
        } else {
            @Suppress("DEPRECATION")
            char.value = bytes
            @Suppress("DEPRECATION")
            char.writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
            @Suppress("DEPRECATION")
            g.writeCharacteristic(char)
        }
    }

    /**
     * Habilita notificações na characteristic selecionada.
     */
    fun enableNotifications(characteristicUuid: UUID? = null): Boolean {
        val g = gatt ?: return false
        val char = when {
            characteristicUuid != null -> findCharacteristic(g, characteristicUuid)
            notifyCharacteristic != null -> notifyCharacteristic
            else -> null
        } ?: return false

        g.setCharacteristicNotification(char, true)
        val cccd = char.getDescriptor(KnownUuids.CCCD) ?: return false
        val value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            g.writeDescriptor(cccd, value) == BluetoothStatusCodes.SUCCESS
        } else {
            @Suppress("DEPRECATION")
            cccd.value = value
            @Suppress("DEPRECATION")
            g.writeDescriptor(cccd)
        }
    }

    fun clearLogs() {
        _logs.value = emptyList()
    }

    fun exportLogsAsText(): String {
        return _logs.value.joinToString("\n") { entry ->
            val ts = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", java.util.Locale.US)
                .apply { timeZone = java.util.TimeZone.getTimeZone("UTC") }
                .format(java.util.Date(entry.timestamp))
            buildString {
                append("$ts ${entry.direction.name}")
                if (entry.characteristicUuid != null) append(" char=${entry.characteristicUuid}")
                if (entry.bytesHex != null) append(" bytes=\"${entry.bytesHex}\"")
                if (entry.gattStatus != null) append(" status=${entry.gattStatus}")
                append(" ${entry.message}")
            }
        }
    }

    private fun selectKnownCharacteristic(g: BluetoothGatt) {
        // Preferência: characteristic conhecida do SDK
        val candidates = listOf(KnownUuids.CHAR_HANDLE_DATA, KnownUuids.CHAR_OTHER)
        for (uuid in candidates) {
            val char = findCharacteristic(g, uuid)
            if (char != null) {
                val info = GattCharacteristicInfo(char.uuid, char.properties, char.permissions)
                if (info.canWrite || info.canWriteNoResponse) {
                    writeCharacteristic = char
                    addLog(LogDirection.INFO, "Selected WRITE char=${char.uuid}")
                }
                if (info.canNotify || info.canIndicate) {
                    notifyCharacteristic = char
                    addLog(LogDirection.INFO, "Selected NOTIFY char=${char.uuid}")
                }
            }
        }
        // Fallback: primeira characteristic com WRITE do serviço conhecido
        if (writeCharacteristic == null) {
            g.services
                .firstOrNull { it.uuid == KnownUuids.SERVICE_GAMESIR }
                ?.characteristics
                ?.firstOrNull {
                    val p = it.properties
                    p and BluetoothGattCharacteristic.PROPERTY_WRITE != 0 ||
                            p and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0
                }
                ?.let {
                    writeCharacteristic = it
                    addLog(LogDirection.INFO, "Fallback WRITE char=${it.uuid}")
                }
        }
    }

    private fun findCharacteristic(g: BluetoothGatt, uuid: UUID): BluetoothGattCharacteristic? {
        for (service in g.services) {
            service.getCharacteristic(uuid)?.let { return it }
        }
        return null
    }

    private fun addLog(
        direction: LogDirection,
        message: String,
        bytesHex: String? = null,
        characteristicUuid: String? = null,
        gattStatus: Int? = null
    ) {
        val entry = LogEntry(
            timestamp = System.currentTimeMillis(),
            direction = direction,
            message = message,
            bytesHex = bytesHex,
            characteristicUuid = characteristicUuid,
            gattStatus = gattStatus
        )
        _logs.value = _logs.value + entry
        Log.d(TAG, "${entry.direction}: $message ${bytesHex ?: ""}")
    }
}
