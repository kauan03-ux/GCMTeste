package com.gamesir.testapp.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.gamesir.testapp.model.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(viewModel: MainViewModel) {
    val connectionState by viewModel.bleManager.connectionState.collectAsState()
    val devices by viewModel.bleManager.scannedDevices.collectAsState()
    val logs by viewModel.bleManager.logs.collectAsState()
    val readOnly by viewModel.readOnlyMode.collectAsState()
    val experimental by viewModel.experimentalUnlocked.collectAsState()
    val selectedPreset by viewModel.selectedPreset.collectAsState()
    val rawHex by viewModel.rawHexInput.collectAsState()
    val hexValidation by viewModel.hexValidation.collectAsState()
    val showResetConfirm by viewModel.showResetConfirm.collectAsState()

    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Dashboard", "GATT", "Console", "Logger")

    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    val permissions = remember {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            arrayOf(
                Manifest.permission.BLUETOOTH_SCAN,
                Manifest.permission.BLUETOOTH_CONNECT
            )
        } else {
            arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.BLUETOOTH,
                Manifest.permission.BLUETOOTH_ADMIN
            )
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val allGranted = results.values.all { it }
        if (allGranted) {
            viewModel.startScan()
        } else {
            scope.launch {
                snackbarHostState.showSnackbar("Permissões BLE necessárias para escanear")
            }
        }
    }

    fun ensurePermissionsAndScan() {
        val missing = permissions.filter {
            ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) {
            viewModel.startScan()
        } else {
            permissionLauncher.launch(permissions)
        }
    }

    if (showResetConfirm) {
        AlertDialog(
            onDismissRequest = { viewModel.cancelReset() },
            title = { Text("⚠ Reset destrutivo") },
            text = {
                Text(
                    "O comando Reset pode apagar a configuração do controle.\n\n" +
                            "Tem certeza? Esta ação exige confirmação dupla conforme o guia de segurança."
                )
            },
            confirmButton = {
                TextButton(onClick = { viewModel.confirmResetAndSend() }) {
                    Text("Confirmar Reset", color = Color.Red)
                }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.cancelReset() }) {
                    Text("Cancelar")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("GameSir Test — Super Nova / T3XS") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                ),
                actions = {
                    // Indicador de modo
                    FilterChip(
                        selected = readOnly,
                        onClick = { viewModel.toggleReadOnly() },
                        label = {
                            Text(
                                if (readOnly) "SOMENTE LEITURA" else "EXPERIMENTAL",
                                fontSize = 11.sp
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFF2E7D32),
                            selectedLabelColor = Color.White,
                            containerColor = Color(0xFFC62828),
                            labelColor = Color.White
                        )
                    )
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { index, title ->
                    NavigationBarItem(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        icon = {
                            Icon(
                                when (index) {
                                    0 -> Icons.Default.Dashboard
                                    1 -> Icons.Default.List
                                    2 -> Icons.Default.Terminal
                                    else -> Icons.Default.Article
                                },
                                contentDescription = title
                            )
                        },
                        label = { Text(title, fontSize = 11.sp) }
                    )
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            when (selectedTab) {
                0 -> DashboardTab(
                    connectionState = connectionState,
                    devices = devices,
                    readOnly = readOnly,
                    experimental = experimental,
                    onScan = { ensurePermissionsAndScan() },
                    onStopScan = { viewModel.stopScan() },
                    onConnect = { viewModel.connect(it) },
                    onDisconnect = { viewModel.disconnect() },
                    onUnlockExperimental = { viewModel.unlockExperimental(it) }
                )
                1 -> GattTab(connectionState)
                2 -> ConsoleTab(
                    presets = viewModel.presets,
                    selectedPreset = selectedPreset,
                    rawHex = rawHex,
                    hexValidation = hexValidation,
                    readOnly = readOnly,
                    onSelectPreset = { viewModel.selectPreset(it) },
                    onHexChange = { viewModel.updateRawHex(it) },
                    onSend = { viewModel.sendCurrentPacket() },
                    onEnableNotify = { viewModel.enableNotifications() }
                )
                3 -> LoggerTab(
                    logs = logs,
                    onClear = { viewModel.clearLogs() },
                    onExport = {
                        val text = viewModel.exportLogs()
                        // Copia para clipboard
                        val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE)
                                as android.content.ClipboardManager
                        clipboard.setPrimaryClip(
                            android.content.ClipData.newPlainText("GameSir Logs", text)
                        )
                        scope.launch {
                            snackbarHostState.showSnackbar("Logs copiados para a área de transferência")
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun DashboardTab(
    connectionState: BleConnectionState,
    devices: List<BleDeviceInfo>,
    readOnly: Boolean,
    experimental: Boolean,
    onScan: () -> Unit,
    onStopScan: () -> Unit,
    onConnect: (String) -> Unit,
    onDisconnect: () -> Unit,
    onUnlockExperimental: (Boolean) -> Unit
) {
    var showUnlockDialog by remember { mutableStateOf(false) }

    if (showUnlockDialog) {
        AlertDialog(
            onDismissRequest = { showUnlockDialog = false },
            title = { Text("Desbloquear modo experimental") },
            text = {
                Text(
                    "O modo experimental permite enviar comandos SET e RESET.\n\n" +
                            "• Faça backup do estado atual se possível\n" +
                            "• Comece por Query, nunca por Reset\n" +
                            "• Valide por read-back e reconexão\n" +
                            "• Um status GATT de sucesso NÃO prova que o firmware aplicou o comando\n\n" +
                            "Continuar?"
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    onUnlockExperimental(true)
                    showUnlockDialog = false
                }) { Text("Desbloquear") }
            },
            dismissButton = {
                TextButton(onClick = { showUnlockDialog = false }) { Text("Cancelar") }
            }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Status card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = when (connectionState) {
                    is BleConnectionState.Connected -> Color(0xFFE8F5E9)
                    is BleConnectionState.Connecting, is BleConnectionState.Scanning -> Color(0xFFFFF3E0)
                    is BleConnectionState.Error -> Color(0xFFFFEBEE)
                    else -> MaterialTheme.colorScheme.surfaceVariant
                }
            )
        ) {
            Column(Modifier.padding(16.dp)) {
                Text("Estado BLE", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                when (connectionState) {
                    is BleConnectionState.Idle -> Text("Inativo")
                    is BleConnectionState.Scanning -> Text("Escaneando…")
                    is BleConnectionState.Connecting -> Text("Conectando a ${connectionState.address}…")
                    is BleConnectionState.Connected -> {
                        Text("Conectado: ${connectionState.name ?: "sem nome"}", fontWeight = FontWeight.Bold)
                        Text(connectionState.address, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                        Text("${connectionState.services.size} serviços descobertos")
                    }
                    is BleConnectionState.Error -> Text("Erro: ${connectionState.message}", color = Color.Red)
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        // Botões de ação
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            when (connectionState) {
                is BleConnectionState.Scanning -> {
                    Button(onClick = onStopScan, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.Stop, null)
                        Spacer(Modifier.width(4.dp))
                        Text("Parar scan")
                    }
                }
                is BleConnectionState.Connected -> {
                    Button(
                        onClick = onDisconnect,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC62828))
                    ) {
                        Icon(Icons.Default.LinkOff, null)
                        Spacer(Modifier.width(4.dp))
                        Text("Desconectar")
                    }
                }
                else -> {
                    Button(onClick = onScan, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.BluetoothSearching, null)
                        Spacer(Modifier.width(4.dp))
                        Text("Escanear")
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        // Toggle experimental
        if (!experimental) {
            OutlinedButton(
                onClick = { showUnlockDialog = true },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.LockOpen, null)
                Spacer(Modifier.width(8.dp))
                Text("Desbloquear modo experimental (SET/RESET)")
            }
        } else {
            OutlinedButton(
                onClick = { onUnlockExperimental(false) },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFC62828))
            ) {
                Icon(Icons.Default.Lock, null)
                Spacer(Modifier.width(8.dp))
                Text("Bloquear novamente (voltar a somente leitura)")
            }
        }

        Spacer(Modifier.height(16.dp))
        Text("Dispositivos encontrados", style = MaterialTheme.typography.titleSmall)
        Spacer(Modifier.height(8.dp))

        if (devices.isEmpty()) {
            Text(
                "Nenhum dispositivo ainda. Toque em Escanear.",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(devices, key = { it.address }) { device ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                if (connectionState !is BleConnectionState.Connected &&
                                    connectionState !is BleConnectionState.Connecting
                                ) {
                                    onConnect(device.address)
                                }
                            }
                    ) {
                        Row(
                            Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Gamepad, null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    device.name ?: "(sem nome)",
                                    fontWeight = FontWeight.Medium
                                )
                                Text(
                                    device.address,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Text("${device.rssi} dBm", fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun GattTab(connectionState: BleConnectionState) {
    val services = (connectionState as? BleConnectionState.Connected)?.services ?: emptyList()

    if (connectionState !is BleConnectionState.Connected) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Conecte a um dispositivo para ver o inventário GATT")
        }
        return
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Text(
                "Inventário GATT — ${services.size} serviços",
                style = MaterialTheme.typography.titleMedium
            )
            Spacer(Modifier.height(8.dp))
        }
        services.forEach { service ->
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text(
                            "Service",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                        SelectionContainer {
                            Text(
                                service.uuid.toString(),
                                fontFamily = FontFamily.Monospace,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        // Destaque se for o serviço conhecido
                        if (service.uuid == KnownUuids.SERVICE_GAMESIR) {
                            Text("★ Serviço Gamesir conhecido (0x8650)", color = Color(0xFF2E7D32), fontSize = 11.sp)
                        }
                        Spacer(Modifier.height(8.dp))
                        service.characteristics.forEach { char ->
                            Column(
                                Modifier
                                    .fillMaxWidth()
                                    .padding(start = 8.dp, bottom = 6.dp)
                                    .background(
                                        MaterialTheme.colorScheme.surfaceVariant,
                                        RoundedCornerShape(6.dp)
                                    )
                                    .padding(8.dp)
                            ) {
                                SelectionContainer {
                                    Text(
                                        char.uuid.toString(),
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 11.sp
                                    )
                                }
                                Text(char.propertiesString(), fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                                if (char.uuid == KnownUuids.CHAR_HANDLE_DATA) {
                                    Text("★ Handle Data (0x8655)", color = Color(0xFF2E7D32), fontSize = 11.sp)
                                }
                                if (char.descriptors.isNotEmpty()) {
                                    Text(
                                        "Descriptors: ${char.descriptors.joinToString { it.toString().takeLast(8) }}",
                                        fontSize = 10.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ConsoleTab(
    presets: List<CommandPreset>,
    selectedPreset: CommandPreset?,
    rawHex: String,
    hexValidation: String,
    readOnly: Boolean,
    onSelectPreset: (CommandPreset?) -> Unit,
    onHexChange: (String) -> Unit,
    onSend: () -> Unit,
    onEnableNotify: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text("Console GCM", style = MaterialTheme.typography.titleMedium)
        Text(
            "Formato: 1F | OP | ID | VALUE | 00 | CHECKSUM",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(12.dp))

        // Presets
        Text("Presets conhecidos", style = MaterialTheme.typography.labelLarge)
        Spacer(Modifier.height(4.dp))
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 180.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            items(presets) { preset ->
                val isDestructive = preset.packet.op == GcmOp.SET || preset.packet.op == GcmOp.RESET
                val enabled = !isDestructive || !readOnly
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(enabled = true) { onSelectPreset(preset) },
                    colors = CardDefaults.cardColors(
                        containerColor = if (selectedPreset == preset)
                            MaterialTheme.colorScheme.primaryContainer
                        else
                            MaterialTheme.colorScheme.surfaceVariant
                    )
                ) {
                    Column(Modifier.padding(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(preset.name, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                            if (isDestructive && readOnly) {
                                Icon(Icons.Default.Lock, null, modifier = Modifier.size(16.dp), tint = Color.Gray)
                            }
                            AssistChip(
                                onClick = {},
                                label = { Text(preset.confidence.name, fontSize = 10.sp) },
                                modifier = Modifier.height(24.dp)
                            )
                        }
                        Text(
                            preset.packet.toHexString(),
                            fontFamily = FontFamily.Monospace,
                            fontSize = 12.sp
                        )
                        Text(preset.description, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        Text("Entrada hexadecimal avançada", style = MaterialTheme.typography.labelLarge)
        OutlinedTextField(
            value = rawHex,
            onValueChange = onHexChange,
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Bytes (ex: 1F 00 01 00 00 20)") },
            singleLine = true,
            textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace)
        )
        Text(
            hexValidation,
            fontSize = 12.sp,
            color = if (hexValidation.startsWith("✓")) Color(0xFF2E7D32) else Color(0xFFC62828)
        )

        Spacer(Modifier.height(12.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = onSend,
                modifier = Modifier.weight(1f),
                enabled = hexValidation.startsWith("✓")
            ) {
                Icon(Icons.Default.Send, null)
                Spacer(Modifier.width(4.dp))
                Text("Enviar")
            }
            OutlinedButton(onClick = onEnableNotify, modifier = Modifier.weight(1f)) {
                Icon(Icons.Default.Notifications, null)
                Spacer(Modifier.width(4.dp))
                Text("Notify")
            }
        }

        if (readOnly) {
            Spacer(Modifier.height(8.dp))
            Text(
                "Modo somente leitura ativo — SET e RESET bloqueados. Desbloqueie no Dashboard.",
                fontSize = 12.sp,
                color = Color(0xFFC62828)
            )
        }
    }
}

@Composable
fun LoggerTab(
    logs: List<LogEntry>,
    onClear: () -> Unit,
    onExport: () -> Unit
) {
    val listState = rememberLazyListState()

    LaunchedEffect(logs.size) {
        if (logs.isNotEmpty()) {
            listState.animateScrollToItem(logs.lastIndex)
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedButton(onClick = onClear, modifier = Modifier.weight(1f)) {
                Icon(Icons.Default.Delete, null)
                Spacer(Modifier.width(4.dp))
                Text("Limpar")
            }
            Button(onClick = onExport, modifier = Modifier.weight(1f)) {
                Icon(Icons.Default.Share, null)
                Spacer(Modifier.width(4.dp))
                Text("Exportar")
            }
        }

        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            items(logs) { entry ->
                val color = when (entry.direction) {
                    LogDirection.TX -> Color(0xFF1565C0)
                    LogDirection.RX -> Color(0xFF2E7D32)
                    LogDirection.ERROR -> Color(0xFFC62828)
                    LogDirection.TIMEOUT -> Color(0xFFE65100)
                    LogDirection.INFO -> MaterialTheme.colorScheme.onSurfaceVariant
                }
                Column(
                    Modifier
                        .fillMaxWidth()
                        .background(color.copy(alpha = 0.08f), RoundedCornerShape(4.dp))
                        .padding(6.dp)
                ) {
                    Text(
                        "${entry.formattedTimestamp()} [${entry.direction.name}]",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = color
                    )
                    if (entry.bytesHex != null) {
                        SelectionContainer {
                            Text(
                                entry.bytesHex,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 12.sp
                            )
                        }
                    }
                    Text(entry.message, fontSize = 11.sp)
                }
            }
        }
    }
}
