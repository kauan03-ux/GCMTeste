package com.gamesir.testapp.protocol

import com.gamesir.testapp.model.GcmOp
import com.gamesir.testapp.model.GcmPacket
import com.gamesir.testapp.model.toHex
import com.gamesir.testapp.protocol.gcm.GcmCodec
import org.junit.Assert.*
import org.junit.Test

/**
 * Fase A — testes offline do codec (guia §11).
 */
class GcmCodecTest {

    @Test
    fun `checksum dos exemplos do guia`() {
        // Query ID 01 → 1F 00 01 00 00 20
        val query = GcmCodec.encodeBasic(GcmOp.QUERY, 0x01, 0x00)
        assertEquals("1F 00 01 00 00 20", query.toHex())
        assertTrue(GcmCodec.isChecksumValid(query))

        // Set ID 01 = C1 → 1F 01 01 C1 00 E2
        val setC1 = GcmCodec.encodeBasic(GcmOp.SET, 0x01, 0xC1)
        assertEquals("1F 01 01 C1 00 E2", setC1.toHex())
        assertTrue(GcmCodec.isChecksumValid(setC1))

        // Reset ID 01 → 1F 02 01 00 00 22
        val reset = GcmCodec.encodeBasic(GcmOp.RESET, 0x01, 0x00)
        assertEquals("1F 02 01 00 00 22", reset.toHex())
        assertTrue(GcmCodec.isChecksumValid(reset))

        // Set ID 01 = B7 → 1F 01 01 B7 00 D8
        val setB7 = GcmCodec.encodeBasic(GcmOp.SET, 0x01, 0xB7)
        assertEquals("1F 01 01 B7 00 D8", setB7.toHex())
        assertTrue(GcmCodec.isChecksumValid(setB7))
    }

    @Test
    fun `checksum invalido e detectado`() {
        val good = GcmCodec.encodeBasic(GcmOp.QUERY, 0x01, 0x00)
        val bad = good.copyOf()
        bad[bad.lastIndex] = (bad.last().toInt() + 1).toByte()
        assertFalse(GcmCodec.isChecksumValid(bad))
    }

    @Test
    fun `pacote truncado rejeitado`() {
        assertFalse(GcmCodec.isChecksumValid(byteArrayOf(0x1F, 0x00)))
        assertNull(GcmPacket.fromBytes(byteArrayOf(0x1F, 0x00, 0x01)))
    }

    @Test
    fun `parse round-trip`() {
        val original = GcmPacket(GcmOp.SET, 0x05, 0xAA)
        val bytes = original.toByteArray()
        val parsed = GcmPacket.fromBytes(bytes)
        assertNotNull(parsed)
        assertEquals(original.op, parsed!!.op)
        assertEquals(original.id, parsed.id)
        assertEquals(original.value, parsed.value)
    }

    @Test
    fun `byte inicial diferente de 1F rejeitado`() {
        val bytes = byteArrayOf(0x2F, 0x00, 0x01, 0x00, 0x00, 0x30)
        // checksum de 2F+00+01+00+00 = 0x30, mas prefixo errado
        assertNull(GcmPacket.fromBytes(bytes))
    }

    @Test
    fun `validateRawHex`() {
        val (ok1, _) = GcmCodec.validateRawHex("1F 00 01 00 00 20")
        assertTrue(ok1)

        val (ok2, msg2) = GcmCodec.validateRawHex("1F 00 01 00 00 21")
        assertFalse(ok2)
        assertTrue(msg2.contains("Checksum"))

        val (ok3, _) = GcmCodec.validateRawHex("ZZ")
        assertFalse(ok3)
    }
}
