# Keep GCM models for potential serialization
-keep class com.gamesir.testapp.model.** { *; }
-keep class com.gamesir.testapp.protocol.** { *; }
